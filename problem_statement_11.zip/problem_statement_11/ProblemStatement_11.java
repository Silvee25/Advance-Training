package problem_statement_11;
import java.util.*;
public class ProblemStatement_11 {

	 static int a[] = {1, 2, 5, 10, 20, 50, 100, 500, 1000};
			    static int n = a.length;
			  
			    static void findMin(int V)
			    {
			   	        Vector<Integer> ans = new Vector<>();
			  
			       	        for (int i = n - 1; i >= 0; i--)
			        {
			           
			            while (V >= a[i]) 
			            {
			                V -=a[i];
			                ans.add(a[i]);
			            }
			        }
			  
			        
			        for (int i = 0; i < ans.size(); i++)
			        {
			            System.out.print(" " + ans.elementAt(i));
			                
			            
			        }
			        System.out.println("\n The minimum number of coins is "+ans.size());
			    }
			  
			   
			    public static void main(String[] args) 
			    {
			    	 Scanner sc=new Scanner(System.in);
			    	   System.out.println("Enter the Number");
			    	   int n=sc.nextInt();
			        
			    	   
			        System.out.print(" Following is minimal number " +"of change for " + n + ": ");
			        findMin(n);
			    }
			}

		

	


