package problem_statement_4;

 class BankAccount {
	int acc_no;
    String name;
    String acc_type;
    double balance;
   
    public int getAcc_no() {
        return acc_no;
    }
   
    public void setAcc_no(int acc_no) {
        this.acc_no = acc_no;
    }
   
    public String getName() {
        return name;
    }
   
    public void setName(String name) {
        this.name = name;
    }
   
    public String getAcc_type() {
        return acc_type;
    }
   
    public void setAcc_type(String acc_type) {
        this.acc_type = acc_type;
    }
   
    public double getBalance() {
       
        if( balance <1000)
        {
        try
        {   
            throw new NumberFormatException();
        }
        catch(NumberFormatException nw)
        {
            System.out.println("Balance is low"+balance);
        }
        }
       
       
        return balance;
       
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }//end setter and getter

    public BankAccount() {
       
        this.acc_no = 100;
        this.name = "AMOl";
        this.acc_type = "Saving";
        this.balance = 500;
    }
   
   
   
   
    public BankAccount(int acc_no, String name, String acc_type,
            double balance) {
       
        this.acc_no = acc_no;
        this.name = name;
        this.acc_type = acc_type;
        this.balance = balance;
    }
    void deposit(double amt)
    {
        if(amt<0)
        {
            try
            {
                throw new NumberFormatException();
            }
            catch(NumberFormatException nf)
            {
                System.out.println("Negaive Amount cant be deposited");
            }
        }
        else
        {
            balance=getBalance()+amt;
            System.out.println("Current balance is ="+balance);
           
        }
       
       
       
    }
     public void withdraw(double amt){
         if(amt>1000)
            {
                try
                {
                    throw new NumberFormatException();
                }
                catch(NumberFormatException nf)
                {
                    System.out.println("WE CANT DEPOSITE AMOUNT INSUFFICENT BALANCE ");
                }
            }
            else
            {
                balance=getBalance()-amt;
                System.out.println("Current balance is ="+balance);
               
            }
       
       
       
       
       
    }
     void display()
     {
    System.out.println("Balance is ="+getBalance());   
     }
   
   
   
   

	public static void main(String[] args) {
		BankAccount b=new BankAccount();
        b.deposit(2000);
        b.display();
        b.withdraw(500);
        b.display();
        b.withdraw(2000);
        b.getBalance();
        b.display();
       
       	

	}

}
