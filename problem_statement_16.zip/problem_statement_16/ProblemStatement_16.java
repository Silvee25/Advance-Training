package problem_statement_16;

public class ProblemStatement_16 {
	static int a(int n)
    {
        if (n <= 1)
            return n;
        return a(n - 1) + a(n - 2);
    }
 
    // Returns number of ways to reach s'th stair
    static int countWays(int s)
    {
        return a(s + 1);
    }
 
	public static void main(String[] args) {
		int s = 1;
        System.out.println("Number of ways = " + countWays(s));

        int x = 3;
        System.out.println("Number of ways = " + countWays(x));

	}

}
