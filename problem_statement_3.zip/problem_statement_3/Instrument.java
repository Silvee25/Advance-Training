package problem_statement_3;

public abstract class Instrument {
	public abstract void Play();
}
