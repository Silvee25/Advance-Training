package problem_statement_13;
import java.util.*;
class Node
{
	int data;
	Node next;

	Node(int data, Node next)
	{
		this.data = data;
		this.next = next;
	}
}
public class ProblemStatement_13 {
	public static Node getNthFromLast(Node head, int y)
	{
		int x = 0;
		Node curr = head;

		while (curr != null)
		{
			curr = curr.next;
			x++;
		}

		if (x >= y)
		{
			curr = head;
			for (int i = 0; i < x - y; i++) {
				curr = curr.next;
			}
		}
		

		return curr;
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number of Nodes in a Linked List:-");
		int x=sc.nextInt();
		System.out.println("Enter Nth Node: ");
		int y=sc.nextInt();
		System.out.println("Enter "+x+" Elements:");
		int keys[] = new int[x];
		for(int i=0;i<x;i++) {
			keys[i]=sc.nextInt();
		}
		Node head = null;
		for (int i = keys.length - 1; i >= 0; i--) {
			head = new Node(keys[i], head);
		}
		
		
		if(y>keys.length) {
			System.out.println(-1);
		}
		Node node = getNthFromLast(head, y);

		if (node != null) {
			System.out.println("N'th node from the end is: " + node.data);
		}

	}

}
