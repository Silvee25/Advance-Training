package problem_statement_2;

public class ProblemStatement2_2 {

	public static void main(String[] args) {
		int i = 1, n = 13, fstTerm = 1, sndTerm = 3;
	    System.out.println("Fibonacci Series till " + n + " terms:");

	    while (i <= n) {
	      System.out.print(fstTerm + ", ");

	      int nextTerm = fstTerm + sndTerm;
	      fstTerm = sndTerm;
	      sndTerm = nextTerm;

	      i++;
	    }
	  }

	}


