package problem_statement_6;
import java.util.*;
public class ProblemStatement6_3 {

	public static void main(String[] args) {
		Vector<Employee> v = addInput();
		display(v);
	}

	private static Vector<Employee> addInput() {
		Employee e1 = new Employee(101,"Klaus","Banglore") ;
		Employee e2 = new Employee(102,"Haley","Pune") ;
		Employee e3 = new Employee(103,"Kol","Odisha") ;
		Vector<Employee> v = new Vector<Employee>();
		v .add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}

	private static void display(Vector<Employee> v) {
	
		for(Employee e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
	}

	}


